"""
Generates a deliberately MESSY dataset of Bengaluru food-delivery orders.
The mess is intentional so the SQL pipeline has real cleaning work to do.

Run:  python generate_data.py        (writes orders_raw.csv and restaurants_raw.csv here)
The CSVs are already included in the repo, so you only need this to regenerate.
"""
import csv
import os
import random
from datetime import datetime, timedelta

random.seed(42)
HERE = os.path.dirname(os.path.abspath(__file__))

AREAS = ["Koramangala", "Indiranagar", "HSR Layout", "Whitefield", "Jayanagar",
         "Electronic City", "Marathahalli", "BTM Layout", "Malleshwaram", "Hebbal"]
# Dirty spellings that real apps/forms produce
AREA_VARIANTS = {
    "Koramangala": ["koramangala", "KORAMANGALA", "Kormangala", " Koramangala "],
    "Indiranagar": ["indiranagar", "Indira Nagar", "INDIRANAGAR"],
    "HSR Layout": ["HSR", "hsr layout", "H.S.R Layout"],
    "Whitefield": ["whitefield", "White Field", "WHITEFIELD "],
    "Jayanagar": ["jayanagar", "Jaya Nagar"],
    "Electronic City": ["E City", "electronic city", "Electronic city"],
    "Marathahalli": ["marathahalli", "Marathalli"],
    "BTM Layout": ["BTM", "btm layout"],
    "Malleshwaram": ["malleshwaram", "Malleswaram"],
    "Hebbal": ["hebbal", " Hebbal"],
}
CUISINES = ["South Indian", "North Indian", "Chinese", "Biryani", "Pizza",
            "Burgers", "Desserts", "Healthy", "Cafe", "Andhra"]
STATUS_VARIANTS = {
    "Delivered": ["Delivered", "delivered", "DELIVERED", "Delivered "],
    "Cancelled": ["Cancelled", "canceled", "CANCELLED", "Cancel"],
    "Refunded": ["Refunded", "refunded"],
}
PAYMENT_VARIANTS = {
    "UPI": ["UPI", "upi", "GPay", "PhonePe", "Paytm UPI"],
    "Card": ["Card", "card", "Credit Card", "Debit Card"],
    "Cash": ["COD", "Cash", "cash on delivery"],
    "Wallet": ["Wallet", "wallet", "Amazon Pay"],
}
NAME_PARTS_A = ["Shree", "Udupi", "Royal", "Spice", "Green", "Urban", "Namma",
                "Golden", "Big", "Little", "Tandoor", "Dragon", "Cafe", "Biryani"]
NAME_PARTS_B = ["Kitchen", "Bhavan", "Express", "House", "Corner", "Point",
                "Garden", "Hub", "Darshini", "Bowl", "Grill", "Junction"]


def messy(value, variants, clean_prob=0.6):
    return value if random.random() < clean_prob else random.choice(variants)


def messy_date(dt):
    fmt = random.choices(
        ["%Y-%m-%d %H:%M:%S", "%d/%m/%Y %H:%M", "%d-%b-%Y %I:%M %p"],
        weights=[70, 20, 10])[0]
    return dt.strftime(fmt)


def messy_amount(x):
    r = random.random()
    if r < 0.70:
        return f"{x:.2f}"
    if r < 0.85:
        return f"₹{x:,.2f}"          # currency symbol + thousands separator
    if r < 0.95:
        return f"Rs. {x:.0f}"
    return ""                        # missing


# ---------------- restaurants ----------------
restaurants = []
used = set()
for rid in range(1, 81):
    while True:
        name = f"{random.choice(NAME_PARTS_A)} {random.choice(NAME_PARTS_B)}"
        if name not in used:
            used.add(name)
            break
    area = random.choice(AREAS)
    restaurants.append({
        "restaurant_id": f"R{rid:03d}",
        "restaurant_name": name if random.random() > 0.15 else f"  {name.upper()} ",
        "cuisine": messy(random.choice(CUISINES), ["", "N/A"], clean_prob=0.93) or "",
        "area": messy(area, AREA_VARIANTS[area], 0.7),
        "avg_cost_for_two": random.choice([200, 300, 350, 400, 500, 600, 800, 1000, 1200]),
        "onboarded_on": messy_date(datetime(2021, 1, 1) + timedelta(days=random.randint(0, 1200))).split(" ")[0],
    })
# duplicate a few restaurant rows (classic dirty-master-data problem)
restaurants += random.sample(restaurants, 4)



def staging_key(v):
    return "".join(ch for ch in v.lower() if ch.isalpha())

# ---------------- orders ----------------
# Realistic patterns are built in so the analysis has real stories to find:
#  * steady growth through the year + festive spike in Oct-Nov (Dussehra/Diwali)
#  * monsoon months (Jun-Sep) and outer areas (Whitefield, E-City) deliver slower
#  * evening rush (7-10 PM) is slower; late deliveries get worse ratings
#  * Cash-on-delivery orders get cancelled far more often
start = datetime(2025, 1, 1)
all_days = [start + timedelta(days=i) for i in range(365)]
day_weights = []
for d in all_days:
    w = 1 + 0.06 * (d.month - 1)                 # growth
    if d.month in (10, 11):
        w *= 1.35                                # festive season
    if d.weekday() >= 5:
        w *= 1.3                                 # weekends
    day_weights.append(w)

AREA_DELAY = {"Whitefield": 9, "Electronic City": 8, "Marathahalli": 5, "Hebbal": 4,
              "BTM Layout": 1, "HSR Layout": 1}
HOUR_WEIGHTS = [1, 1, 0, 0, 0, 0, 1, 2, 4, 5, 4, 6, 12, 14, 8, 5, 4, 6, 9, 14, 16, 12, 6, 3]


def rating_for(minutes):
    if minutes <= 30:
        w = [45, 35, 12, 5, 3]
    elif minutes <= 40:
        w = [30, 38, 18, 9, 5]
    elif minutes <= 50:
        w = [15, 30, 27, 16, 12]
    else:
        w = [6, 16, 26, 26, 26]
    return str(random.choices([5, 4, 3, 2, 1], weights=w)[0])


orders = []
for oid in range(1, 6001):
    r = random.choice(restaurants[:80])
    day = random.choices(all_days, weights=day_weights)[0]
    hour = random.choices(range(24), weights=HOUR_WEIGHTS)[0]
    ts = day.replace(hour=hour, minute=random.randint(0, 59), second=random.randint(0, 59))

    clean_r_area = next(a for a in AREAS if staging_key(a) == staging_key(r["area"]) or
                        any(staging_key(v) == staging_key(r["area"]) for v in AREA_VARIANTS[a]))
    cust_area = clean_r_area if random.random() < 0.7 else random.choice(AREAS)

    items = random.randint(1, 6)
    base = random.uniform(120, 450) * items * (1.15 if day.month in (10, 11) else 1)
    discount = round(base * random.choice([0, 0, 0, 0.1, 0.2, 0.3]), 2)
    delivery_fee = random.choice([0, 0, 25, 35, 49])

    pay = random.choices(list(PAYMENT_VARIANTS), weights=[60, 20, 12, 8])[0]
    cancel_w = 22 if pay == "Cash" else 7
    status = random.choices(["Delivered", "Cancelled", "Refunded"], weights=[100 - cancel_w - 4, cancel_w, 4])[0]

    minutes = random.gauss(28, 6) + AREA_DELAY.get(cust_area, 0)
    if 6 <= day.month <= 9:
        minutes += 6                              # monsoon traffic
    if 19 <= hour <= 21:
        minutes += 5                              # dinner rush
    delivery_min = max(8, int(minutes))
    rating = rating_for(delivery_min) if random.random() > 0.12 else ""
    if random.random() < 0.01:
        delivery_min = -delivery_min             # impossible negative times
    if random.random() < 0.005:
        delivery_min = 999                       # typo outlier
    if random.random() < 0.025:
        rating = random.choice(["0", "6"])       # out-of-range ratings
    if status != "Delivered":
        rating = ""

    customer = f"C{int(random.paretovariate(1.2)) % 1500 + 1:05d}" if random.random() < 0.5 \
        else f"C{random.randint(1, 1500):05d}"   # some heavy repeat customers
    if random.random() < 0.05:
        customer = customer.lower()

    orders.append({
        "order_id": f"ORD{oid:06d}",
        "order_time": messy_date(ts),
        "customer_id": customer,
        "customer_area": messy(cust_area, AREA_VARIANTS[cust_area]),
        "restaurant_id": r["restaurant_id"] if random.random() > 0.01 else "R999",  # orphan FK
        "items_count": str(items) if random.random() > 0.02 else "",
        "order_value": messy_amount(base),
        "discount": f"{discount:.2f}",
        "delivery_fee": str(delivery_fee),
        "payment_method": messy(pay, PAYMENT_VARIANTS[pay]),
        "order_status": messy(status, STATUS_VARIANTS[status]),
        "delivery_time_min": str(delivery_min) if status == "Delivered" else "",
        "rating": rating,
    })

# exact duplicate rows (double-submitted events)
orders += random.sample(orders, 120)
random.shuffle(orders)

with open(os.path.join(HERE, "restaurants_raw.csv"), "w", newline="", encoding="utf-8") as f:
    w = csv.DictWriter(f, fieldnames=restaurants[0].keys())
    w.writeheader()
    w.writerows(restaurants)

with open(os.path.join(HERE, "orders_raw.csv"), "w", newline="", encoding="utf-8") as f:
    w = csv.DictWriter(f, fieldnames=orders[0].keys())
    w.writeheader()
    w.writerows(orders)

print(f"restaurants_raw.csv: {len(restaurants)} rows")
print(f"orders_raw.csv:      {len(orders)} rows")
