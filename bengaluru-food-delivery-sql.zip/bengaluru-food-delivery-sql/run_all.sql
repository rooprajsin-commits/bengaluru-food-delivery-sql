-- =====================================================================
-- run_all.sql — runs the whole pipeline end to end.
-- From the project root:
--     createdb food_delivery
--     psql -d food_delivery -f run_all.sql
-- =====================================================================
\set ON_ERROR_STOP on
\timing off
SET client_min_messages = warning;

\echo '>>> 00 Setup schemas'
\i sql/00_setup.sql
\echo '>>> 01 Extract: load raw CSVs'
\i sql/01_load_raw.sql
\echo '>>> 02 Profile: data-quality audit'
\i sql/02_data_quality_audit.sql
\echo '>>> 03 Clean: raw -> staging'
\i sql/03_clean.sql
\echo '>>> 04 Transform: staging -> star schema'
\i sql/04_transform.sql
\echo '>>> 05 Reporting views'
\i sql/05_reporting_views.sql
\echo '>>> 06 Visualise'
\i sql/06_visualize.sql
