-- =====================================================================
-- 02_data_quality_audit.sql  (PROFILE)
-- Before cleaning anything, measure what is wrong. This produces a
-- data-quality scorecard you can quote in interviews:
-- "I found X duplicates, Y unparseable dates, Z spellings of one area..."
-- =====================================================================

\echo
\echo '==================  DATA QUALITY AUDIT: raw.orders  =================='

WITH checks AS (
    SELECT 1 AS n, 'Total rows'                           AS check_name, count(*) AS issue_rows FROM raw.orders
    UNION ALL
    SELECT 2, 'Duplicate order_id rows',
           count(*) - count(DISTINCT order_id)                         FROM raw.orders
    UNION ALL
    SELECT 3, 'Order time NOT in ISO format (YYYY-MM-DD)',
           count(*) FILTER (WHERE order_time !~ '^\d{4}-\d{2}-\d{2}')  FROM raw.orders
    UNION ALL
    SELECT 4, 'Order value missing',
           count(*) FILTER (WHERE coalesce(trim(order_value),'') = '') FROM raw.orders
    UNION ALL
    SELECT 5, 'Order value with currency text (₹ / Rs / commas)',
           count(*) FILTER (WHERE order_value ~ '[₹,R]')               FROM raw.orders
    UNION ALL
    SELECT 6, 'Items count missing',
           count(*) FILTER (WHERE coalesce(items_count,'') = '')       FROM raw.orders
    UNION ALL
    SELECT 7, 'Rating outside 1-5',
           count(*) FILTER (WHERE rating IN ('0','6'))                 FROM raw.orders
    UNION ALL
    SELECT 8, 'Negative or >180 min delivery time',
           count(*) FILTER (WHERE delivery_time_min ~ '^-?\d+$'
                              AND (delivery_time_min::int < 0
                                OR delivery_time_min::int > 180))       FROM raw.orders
    UNION ALL
    SELECT 9, 'Restaurant id not in restaurant master',
           count(*) FILTER (WHERE restaurant_id NOT IN
                            (SELECT restaurant_id FROM raw.restaurants)) FROM raw.orders
    UNION ALL
    SELECT 10, 'Customer id in lowercase',
           count(*) FILTER (WHERE customer_id <> upper(customer_id))   FROM raw.orders
)
SELECT check_name, issue_rows FROM checks ORDER BY n;

\echo
\echo '---- Inconsistent category labels (distinct spellings per field) ----'
SELECT 'customer_area'  AS field, count(DISTINCT customer_area)  AS distinct_values_raw FROM raw.orders
UNION ALL
SELECT 'order_status',            count(DISTINCT order_status)   FROM raw.orders
UNION ALL
SELECT 'payment_method',          count(DISTINCT payment_method) FROM raw.orders;

\echo
\echo '---- Example: every spelling of order_status found in the source ----'
SELECT '"' || order_status || '"' AS raw_value, count(*) AS rows
FROM raw.orders
GROUP BY order_status
ORDER BY rows DESC;

\echo
\echo '==================  DATA QUALITY AUDIT: raw.restaurants  =================='
SELECT
    count(*)                                                         AS total_rows,
    count(*) - count(DISTINCT restaurant_id)                         AS duplicate_rows,
    count(*) FILTER (WHERE restaurant_name <> trim(restaurant_name)) AS names_with_extra_spaces,
    count(*) FILTER (WHERE restaurant_name = upper(restaurant_name)) AS names_in_all_caps,
    count(*) FILTER (WHERE coalesce(cuisine,'') IN ('','N/A'))       AS missing_cuisine
FROM raw.restaurants;
