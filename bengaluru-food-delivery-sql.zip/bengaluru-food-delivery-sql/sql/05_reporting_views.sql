-- =====================================================================
-- 05_reporting_views.sql  (SEMANTIC LAYER)
-- Business-ready views. Any BI tool (Power BI, Tableau, Metabase,
-- Excel) can connect to PostgreSQL and read these directly.
-- Techniques shown: CTEs, window functions (LAG, NTILE, SUM OVER,
-- FIRST_VALUE), FILTER aggregates, cohort analysis, RFM segmentation.
-- =====================================================================

-- ---------------------------------------------------------------------
-- 1. Monthly KPIs with month-over-month growth
-- ---------------------------------------------------------------------
CREATE VIEW analytics.v_monthly_kpis AS
WITH m AS (
    SELECT d.month_start,
           d.month_name,
           count(*)                                              AS total_orders,
           count(*) FILTER (WHERE f.order_status = 'Delivered')  AS delivered_orders,
           sum(f.net_revenue)                                    AS revenue,
           count(DISTINCT f.customer_key)                        AS active_customers,
           round(100.0 * count(*) FILTER (WHERE f.order_status = 'Cancelled') / count(*), 1) AS cancel_rate_pct
    FROM analytics.fact_orders f
    JOIN analytics.dim_date d USING (date_key)
    GROUP BY d.month_start, d.month_name
)
SELECT month_start, month_name, total_orders, delivered_orders, active_customers,
       revenue,
       round(revenue / NULLIF(delivered_orders, 0), 2)                         AS avg_order_value,
       cancel_rate_pct,
       round(100.0 * (revenue - LAG(revenue) OVER (ORDER BY month_start))
                   / NULLIF(LAG(revenue) OVER (ORDER BY month_start), 0), 1)  AS revenue_mom_pct,
       sum(revenue) OVER (ORDER BY month_start)                                AS revenue_ytd
FROM m;

-- ---------------------------------------------------------------------
-- 2. Area (locality) performance with revenue share and rank
-- ---------------------------------------------------------------------
CREATE VIEW analytics.v_area_performance AS
SELECT f.customer_area                                         AS area,
       count(*)                                                AS orders,
       sum(f.net_revenue)                                      AS revenue,
       round(100.0 * sum(f.net_revenue) / sum(sum(f.net_revenue)) OVER (), 1) AS revenue_share_pct,
       round(avg(f.delivery_time_min), 1)                      AS avg_delivery_min,
       round(100.0 * avg(f.is_late::INT), 1)                   AS late_pct,
       round(avg(f.rating), 2)                                 AS avg_rating,
       RANK() OVER (ORDER BY sum(f.net_revenue) DESC)          AS revenue_rank
FROM analytics.fact_orders f
GROUP BY f.customer_area;

-- ---------------------------------------------------------------------
-- 3. Cuisine performance
-- ---------------------------------------------------------------------
CREATE VIEW analytics.v_cuisine_performance AS
SELECT r.cuisine,
       count(*)                                                          AS orders,
       sum(f.net_revenue)                                                AS revenue,
       round(avg(f.gross_value) FILTER (WHERE f.order_status='Delivered'), 2) AS avg_order_value,
       round(avg(f.rating), 2)                                           AS avg_rating,
       round(100.0 * avg((f.discount > 0)::INT), 1)                      AS pct_orders_discounted
FROM analytics.fact_orders f
JOIN analytics.dim_restaurant r USING (restaurant_key)
GROUP BY r.cuisine;

-- ---------------------------------------------------------------------
-- 4. Demand by weekday x hour (for the peak-hours heatmap)
-- ---------------------------------------------------------------------
CREATE VIEW analytics.v_demand_by_hour AS
SELECT d.weekday_num, d.weekday_name, f.order_hour, count(*) AS orders
FROM analytics.fact_orders f
JOIN analytics.dim_date d USING (date_key)
GROUP BY d.weekday_num, d.weekday_name, f.order_hour;

-- ---------------------------------------------------------------------
-- 5. Top restaurants (rank within each cuisine)
-- ---------------------------------------------------------------------
CREATE VIEW analytics.v_restaurant_leaderboard AS
SELECT r.restaurant_name, r.cuisine, r.area, r.price_band,
       count(*)                     AS orders,
       sum(f.net_revenue)           AS revenue,
       round(avg(f.rating), 2)      AS avg_rating,
       DENSE_RANK() OVER (PARTITION BY r.cuisine ORDER BY sum(f.net_revenue) DESC) AS rank_in_cuisine
FROM analytics.fact_orders f
JOIN analytics.dim_restaurant r USING (restaurant_key)
GROUP BY r.restaurant_key, r.restaurant_name, r.cuisine, r.area, r.price_band;

-- ---------------------------------------------------------------------
-- 6. RFM customer segmentation (Recency, Frequency, Monetary)
-- ---------------------------------------------------------------------
CREATE VIEW analytics.v_customer_rfm AS
WITH base AS (
    SELECT c.customer_id,
           (SELECT max(order_ts)::DATE FROM analytics.fact_orders) - max(f.order_ts)::DATE AS recency_days,
           count(*)               AS frequency,
           sum(f.net_revenue)     AS monetary
    FROM analytics.fact_orders f
    JOIN analytics.dim_customer c USING (customer_key)
    WHERE f.order_status = 'Delivered'
    GROUP BY c.customer_id
),
scored AS (
    SELECT *,
           NTILE(4) OVER (ORDER BY recency_days DESC) AS r_score,   -- recent = 4
           NTILE(4) OVER (ORDER BY frequency)         AS f_score,
           NTILE(4) OVER (ORDER BY monetary)          AS m_score
    FROM base
)
SELECT *,
       CASE
           WHEN r_score >= 3 AND f_score >= 3 AND m_score >= 3 THEN 'Champions'
           WHEN r_score >= 3 AND f_score >= 2                  THEN 'Loyal'
           WHEN r_score >= 3                                   THEN 'New / Promising'
           WHEN r_score = 2                                    THEN 'Needs Attention'
           WHEN f_score >= 3                                   THEN 'At Risk (was valuable)'
           ELSE 'Hibernating'
       END AS segment
FROM scored;

-- ---------------------------------------------------------------------
-- 7. Monthly cohort retention
--    % of customers from each first-order month who ordered again N months later
-- ---------------------------------------------------------------------
CREATE VIEW analytics.v_cohort_retention AS
WITH activity AS (
    SELECT DISTINCT c.customer_key, c.cohort_month,
           date_trunc('month', f.order_ts)::DATE AS active_month
    FROM analytics.fact_orders f
    JOIN analytics.dim_customer c USING (customer_key)
),
counts AS (
    SELECT cohort_month,
           (EXTRACT(YEAR FROM age(active_month, cohort_month)) * 12
          + EXTRACT(MONTH FROM age(active_month, cohort_month)))::INT AS month_offset,
           count(DISTINCT customer_key) AS customers
    FROM activity
    GROUP BY 1, 2
)
SELECT cohort_month, month_offset, customers,
       FIRST_VALUE(customers) OVER (PARTITION BY cohort_month ORDER BY month_offset) AS cohort_size,
       round(100.0 * customers
             / FIRST_VALUE(customers) OVER (PARTITION BY cohort_month ORDER BY month_offset), 1) AS retention_pct
FROM counts;

-- ---------------------------------------------------------------------
-- 8. Does late delivery hurt ratings?  (delivery-time buckets vs rating)
-- ---------------------------------------------------------------------
CREATE VIEW analytics.v_delivery_vs_rating AS
SELECT CASE
           WHEN delivery_time_min <= 25 THEN '1) <= 25 min'
           WHEN delivery_time_min <= 35 THEN '2) 26-35 min'
           WHEN delivery_time_min <= 45 THEN '3) 36-45 min'
           ELSE                              '4) > 45 min (late)'
       END                           AS delivery_bucket,
       count(*)                      AS rated_orders,
       round(avg(rating), 2)         AS avg_rating,
       round(100.0 * avg((rating <= 2)::INT), 1) AS pct_bad_ratings
FROM analytics.fact_orders
WHERE delivery_time_min IS NOT NULL AND rating IS NOT NULL
GROUP BY 1;

-- ---------------------------------------------------------------------
-- 9. Payment mix and cancellation rate per payment method
-- ---------------------------------------------------------------------
CREATE VIEW analytics.v_payment_mix AS
SELECT payment_method,
       count(*)                                                     AS orders,
       round(100.0 * count(*) / sum(count(*)) OVER (), 1)           AS share_pct,
       round(100.0 * avg((order_status = 'Cancelled')::INT), 1)     AS cancel_rate_pct
FROM analytics.fact_orders
GROUP BY payment_method;

\echo
\echo 'Reporting views created:'
SELECT table_name AS view_name
FROM information_schema.views
WHERE table_schema = 'analytics'
ORDER BY 1;
