-- =====================================================================
-- 06_visualize.sql  (VISUALISE — inside PostgreSQL itself)
-- Text charts rendered by SQL: bar charts, a growth line, a weekday x hour
-- heatmap and a cohort grid. Run in psql (or the pgAdmin query tool) and
-- the charts appear in the result grid — no BI tool needed.
-- =====================================================================

-- Helper: horizontal bar scaled to the largest value in the set
CREATE OR REPLACE FUNCTION analytics.bar(val NUMERIC, max_val NUMERIC, width INT DEFAULT 40)
RETURNS TEXT LANGUAGE sql IMMUTABLE AS $$
    SELECT repeat('█', greatest(0, round(coalesce(val,0) / NULLIF(max_val,0) * width))::INT)
$$;

-- Helper: one heatmap cell, darker = higher
CREATE OR REPLACE FUNCTION analytics.shade(val NUMERIC, max_val NUMERIC)
RETURNS TEXT LANGUAGE sql IMMUTABLE AS $$
    SELECT (ARRAY['  ','░░','▒▒','▓▓','██'])
           [1 + least(4, floor(coalesce(val,0) / NULLIF(max_val,0) * 5))::INT]
$$;

\pset footer off

\echo
\echo '╔══════════════════════════════════════════════════════════════╗'
\echo '║  CHART 1 · Monthly revenue (₹) and month-over-month growth   ║'
\echo '╚══════════════════════════════════════════════════════════════╝'
SELECT month_name                                        AS month,
       to_char(revenue, 'FM99,99,999')                    AS revenue_inr,
       analytics.bar(revenue, max(revenue) OVER (), 40)   AS chart,
       CASE WHEN revenue_mom_pct IS NULL THEN ''
            WHEN revenue_mom_pct >= 0   THEN '▲ ' || revenue_mom_pct || '%'
            ELSE '▼ ' || abs(revenue_mom_pct) || '%' END   AS mom
FROM analytics.v_monthly_kpis
ORDER BY month_start;

\echo
\echo '╔══════════════════════════════════════════════════════════════╗'
\echo '║  CHART 2 · Revenue share by Bengaluru area                    ║'
\echo '╚══════════════════════════════════════════════════════════════╝'
SELECT revenue_rank                                            AS "#",
       area,
       revenue_share_pct || '%'                                AS share,
       analytics.bar(revenue_share_pct, max(revenue_share_pct) OVER (), 35) AS chart
FROM analytics.v_area_performance
ORDER BY revenue_rank;

\echo
\echo '╔══════════════════════════════════════════════════════════════╗'
\echo '║  CHART 2b · Delivery SLA by area (% orders later than 45 min) ║'
\echo '╚══════════════════════════════════════════════════════════════╝'
SELECT area,
       avg_delivery_min                                   AS avg_min,
       late_pct || '%'                                    AS late,
       analytics.bar(late_pct, max(late_pct) OVER (), 35) AS chart,
       avg_rating
FROM analytics.v_area_performance
ORDER BY late_pct DESC;

\echo
\echo '╔══════════════════════════════════════════════════════════════╗'
\echo '║  CHART 3 · Peak-hours heatmap (orders by weekday x hour)      ║'
\echo '║  legend:  "  " low   ░░   ▒▒   ▓▓   ██ high                   ║'
\echo '╚══════════════════════════════════════════════════════════════╝'
WITH grid AS (
    SELECT w.weekday_num, w.weekday_name, h.hr,
           coalesce(v.orders, 0) AS orders
    FROM (SELECT DISTINCT weekday_num, weekday_name FROM analytics.dim_date) w
    CROSS JOIN generate_series(0, 23) AS h(hr)
    LEFT JOIN analytics.v_demand_by_hour v
           ON v.weekday_num = w.weekday_num AND v.order_hour = h.hr
)
SELECT weekday_name AS day,
       string_agg(analytics.shade(orders, (SELECT max(orders) FROM grid)), '' ORDER BY hr)
           AS "00  02  04  06  08  10  12  14  16  18  20  22  ",
       sum(orders) AS orders
FROM grid
GROUP BY weekday_num, weekday_name
ORDER BY weekday_num;

\echo
\echo '╔══════════════════════════════════════════════════════════════╗'
\echo '║  CHART 4 · Late delivery vs customer rating                   ║'
\echo '╚══════════════════════════════════════════════════════════════╝'
SELECT delivery_bucket,
       avg_rating,
       analytics.bar(avg_rating, 5, 30)               AS rating_out_of_5,
       pct_bad_ratings || '%'                         AS "1-2 star share"
FROM analytics.v_delivery_vs_rating
ORDER BY delivery_bucket;

\echo
\echo '╔══════════════════════════════════════════════════════════════╗'
\echo '║  CHART 5 · Customer segments (RFM)                            ║'
\echo '╚══════════════════════════════════════════════════════════════╝'
SELECT segment,
       count(*)                                                  AS customers,
       to_char(sum(monetary), 'FM99,99,999')                     AS revenue_inr,
       analytics.bar(sum(monetary), max(sum(monetary)) OVER (), 35) AS revenue_chart
FROM analytics.v_customer_rfm
GROUP BY segment
ORDER BY sum(monetary) DESC;

\echo
\echo '╔══════════════════════════════════════════════════════════════╗'
\echo '║  CHART 6 · Cuisine scorecard                                  ║'
\echo '╚══════════════════════════════════════════════════════════════╝'
SELECT cuisine,
       orders,
       avg_order_value                                         AS aov_inr,
       avg_rating,
       analytics.bar(revenue, max(revenue) OVER (), 30)        AS revenue_chart
FROM analytics.v_cuisine_performance
ORDER BY revenue DESC;

\echo
\echo '╔══════════════════════════════════════════════════════════════╗'
\echo '║  CHART 7 · Cohort retention grid (% of cohort ordering again) ║'
\echo '╚══════════════════════════════════════════════════════════════╝'
SELECT to_char(cohort_month, 'Mon')  AS cohort,
       max(cohort_size)              AS size,
       string_agg(lpad(retention_pct::INT::TEXT, 4), '' ORDER BY month_offset)
           FILTER (WHERE month_offset BETWEEN 0 AND 6) AS "   M0  M1  M2  M3  M4  M5  M6"
FROM analytics.v_cohort_retention
GROUP BY cohort_month
ORDER BY cohort_month;

\echo
\echo '╔══════════════════════════════════════════════════════════════╗'
\echo '║  CHART 8 · Payment mix & cancellation rate                    ║'
\echo '╚══════════════════════════════════════════════════════════════╝'
SELECT payment_method,
       share_pct || '%'                                AS share,
       analytics.bar(share_pct, 100, 40)               AS chart,
       cancel_rate_pct || '%'                          AS cancel_rate
FROM analytics.v_payment_mix
ORDER BY share_pct DESC;

\pset footer on
