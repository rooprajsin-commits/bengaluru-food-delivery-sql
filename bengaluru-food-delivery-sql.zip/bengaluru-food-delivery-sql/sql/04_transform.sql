-- =====================================================================
-- 04_transform.sql  (TRANSFORM / MODEL)
-- staging -> analytics star schema
--
--                 dim_date
--                    |
--   dim_customer -- fact_orders -- dim_restaurant
--
-- Techniques shown: surrogate keys (IDENTITY), generate_series date
-- dimension, GENERATED columns, foreign keys, CHECK constraints, indexes,
-- DISTINCT ON / mode() for customer attributes.
-- =====================================================================

-- ---------------------------------------------------------------------
-- dim_date: one row per calendar day of the data range
-- ---------------------------------------------------------------------
CREATE TABLE analytics.dim_date AS
SELECT
    to_char(d, 'YYYYMMDD')::INT                     AS date_key,
    d::DATE                                         AS full_date,
    EXTRACT(YEAR    FROM d)::INT                    AS year,
    EXTRACT(QUARTER FROM d)::INT                    AS quarter,
    EXTRACT(MONTH   FROM d)::INT                    AS month_num,
    to_char(d, 'Mon')                               AS month_name,
    date_trunc('month', d)::DATE                    AS month_start,
    EXTRACT(ISODOW  FROM d)::INT                    AS weekday_num,   -- 1 = Mon
    to_char(d, 'Dy')                                AS weekday_name,
    EXTRACT(ISODOW  FROM d) IN (6, 7)               AS is_weekend
FROM generate_series(
        (SELECT min(order_ts)::DATE FROM staging.orders),
        (SELECT max(order_ts)::DATE FROM staging.orders),
        INTERVAL '1 day') AS d;

ALTER TABLE analytics.dim_date ADD PRIMARY KEY (date_key);

-- ---------------------------------------------------------------------
-- dim_restaurant
-- ---------------------------------------------------------------------
CREATE TABLE analytics.dim_restaurant (
    restaurant_key    INT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    restaurant_id     TEXT UNIQUE NOT NULL,          -- natural / business key
    restaurant_name   TEXT NOT NULL,
    cuisine           TEXT NOT NULL,
    area              TEXT NOT NULL,
    zone              TEXT NOT NULL,
    avg_cost_for_two  INT,
    price_band        TEXT,
    onboarded_on      DATE
);

INSERT INTO analytics.dim_restaurant
      (restaurant_id, restaurant_name, cuisine, area, zone, avg_cost_for_two, price_band, onboarded_on)
SELECT restaurant_id, restaurant_name, cuisine, area, zone, avg_cost_for_two,
       CASE WHEN avg_cost_for_two <  400 THEN 'Budget'
            WHEN avg_cost_for_two <= 800 THEN 'Mid-range'
            ELSE 'Premium' END,
       onboarded_on
FROM staging.restaurants;

-- ---------------------------------------------------------------------
-- dim_customer: derived from order history
-- ---------------------------------------------------------------------
CREATE TABLE analytics.dim_customer (
    customer_key      INT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    customer_id       TEXT UNIQUE NOT NULL,
    home_area         TEXT,                 -- the area they order from most often
    first_order_date  DATE,
    cohort_month      DATE                  -- month of first order (for retention analysis)
);

INSERT INTO analytics.dim_customer (customer_id, home_area, first_order_date, cohort_month)
SELECT customer_id,
       mode() WITHIN GROUP (ORDER BY customer_area),
       min(order_ts)::DATE,
       date_trunc('month', min(order_ts))::DATE
FROM staging.orders
GROUP BY customer_id;

-- ---------------------------------------------------------------------
-- fact_orders: one row per order (grain = order)
-- ---------------------------------------------------------------------
CREATE TABLE analytics.fact_orders (
    order_id           TEXT PRIMARY KEY,
    date_key           INT  NOT NULL REFERENCES analytics.dim_date(date_key),
    customer_key       INT  NOT NULL REFERENCES analytics.dim_customer(customer_key),
    restaurant_key     INT  NOT NULL REFERENCES analytics.dim_restaurant(restaurant_key),
    order_ts           TIMESTAMP NOT NULL,
    order_hour         INT  NOT NULL CHECK (order_hour BETWEEN 0 AND 23),
    customer_area      TEXT NOT NULL,
    payment_method     TEXT NOT NULL,
    order_status       TEXT NOT NULL CHECK (order_status IN ('Delivered','Cancelled','Refunded')),
    items_count        INT,
    gross_value        NUMERIC(12,2) NOT NULL CHECK (gross_value >= 0),
    discount           NUMERIC(12,2) NOT NULL DEFAULT 0,
    delivery_fee       NUMERIC(12,2) NOT NULL DEFAULT 0,
    -- revenue only counts for delivered orders; computed by the database itself
    net_revenue        NUMERIC(12,2) GENERATED ALWAYS AS (
                           CASE WHEN order_status = 'Delivered'
                                THEN gross_value - discount + delivery_fee ELSE 0 END) STORED,
    delivery_time_min  INT CHECK (delivery_time_min BETWEEN 1 AND 180),
    is_late            BOOLEAN GENERATED ALWAYS AS (delivery_time_min > 45) STORED,
    rating             INT CHECK (rating BETWEEN 1 AND 5)
);

INSERT INTO analytics.fact_orders
      (order_id, date_key, customer_key, restaurant_key, order_ts, order_hour,
       customer_area, payment_method, order_status, items_count,
       gross_value, discount, delivery_fee, delivery_time_min, rating)
SELECT o.order_id,
       to_char(o.order_ts, 'YYYYMMDD')::INT,
       c.customer_key,
       r.restaurant_key,
       o.order_ts,
       EXTRACT(HOUR FROM o.order_ts)::INT,
       o.customer_area, o.payment_method, o.order_status, o.items_count,
       o.order_value, o.discount, o.delivery_fee, o.delivery_time_min, o.rating
FROM staging.orders o
JOIN analytics.dim_customer   c ON c.customer_id   = o.customer_id
JOIN analytics.dim_restaurant r ON r.restaurant_id = o.restaurant_id;

-- Indexes on the columns most reports filter / join on
CREATE INDEX idx_fact_date        ON analytics.fact_orders (date_key);
CREATE INDEX idx_fact_customer    ON analytics.fact_orders (customer_key);
CREATE INDEX idx_fact_restaurant  ON analytics.fact_orders (restaurant_key);
CREATE INDEX idx_fact_status      ON analytics.fact_orders (order_status);

\echo
\echo '==================  STAR SCHEMA BUILT  =================='
SELECT 'dim_date' AS table_name, count(*) AS rows FROM analytics.dim_date
UNION ALL SELECT 'dim_restaurant', count(*) FROM analytics.dim_restaurant
UNION ALL SELECT 'dim_customer',   count(*) FROM analytics.dim_customer
UNION ALL SELECT 'fact_orders',    count(*) FROM analytics.fact_orders;

-- Reconciliation check: fact must match staging exactly (no rows lost in joins)
SELECT CASE WHEN (SELECT count(*) FROM analytics.fact_orders) = (SELECT count(*) FROM staging.orders)
            THEN 'PASS: fact_orders reconciles with staging.orders'
            ELSE 'FAIL: row count mismatch between staging and fact' END AS reconciliation;
