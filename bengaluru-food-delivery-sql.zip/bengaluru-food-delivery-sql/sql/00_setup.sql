-- =====================================================================
-- 00_setup.sql
-- Creates the three-layer warehouse layout used by this project:
--   raw        -> data exactly as it arrived (everything TEXT, nothing trusted)
--   staging    -> cleaned, typed, de-duplicated data + a log of rejected rows
--   analytics  -> star schema (facts + dimensions) and reporting views
-- Safe to re-run: drops and rebuilds everything.
-- =====================================================================

DROP SCHEMA IF EXISTS analytics CASCADE;
DROP SCHEMA IF EXISTS staging   CASCADE;
DROP SCHEMA IF EXISTS raw       CASCADE;

CREATE SCHEMA raw;
CREATE SCHEMA staging;
CREATE SCHEMA analytics;

COMMENT ON SCHEMA raw       IS 'Landing zone: source files loaded as-is, all columns TEXT';
COMMENT ON SCHEMA staging   IS 'Cleaned, typed and validated data';
COMMENT ON SCHEMA analytics IS 'Star schema and reporting views for BI / analysis';
