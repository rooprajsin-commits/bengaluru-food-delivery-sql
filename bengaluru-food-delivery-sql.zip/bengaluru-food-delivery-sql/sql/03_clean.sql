-- =====================================================================
-- 03_clean.sql  (CLEAN)
-- raw  ->  staging
-- Techniques shown: reusable SQL functions, regex parsing, CASE mapping,
-- lookup (mapping) tables, ROW_NUMBER() de-duplication, validation rules,
-- and a rejected-rows log so no data silently disappears.
-- =====================================================================

-- ---------------------------------------------------------------------
-- 1. Reusable cleaning functions
-- ---------------------------------------------------------------------

-- Parses the 3 timestamp formats found in the source into one TIMESTAMP.
CREATE OR REPLACE FUNCTION staging.parse_ts(v TEXT)
RETURNS TIMESTAMP
LANGUAGE plpgsql IMMUTABLE AS $$
BEGIN
    v := trim(v);
    IF v IS NULL OR v = '' THEN RETURN NULL; END IF;

    IF v ~ '^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$' THEN          -- 2025-04-02 14:34:15
        RETURN to_timestamp(v, 'YYYY-MM-DD HH24:MI:SS')::timestamp;
    ELSIF v ~ '^\d{4}-\d{2}-\d{2}$' THEN                          -- 2025-04-02
        RETURN to_timestamp(v, 'YYYY-MM-DD')::timestamp;
    ELSIF v ~ '^\d{2}/\d{2}/\d{4} \d{2}:\d{2}$' THEN              -- 29/10/2025 16:32
        RETURN to_timestamp(v, 'DD/MM/YYYY HH24:MI')::timestamp;
    ELSIF v ~ '^\d{2}/\d{2}/\d{4}$' THEN                          -- 29/10/2025
        RETURN to_timestamp(v, 'DD/MM/YYYY')::timestamp;
    ELSIF v ~* '^\d{2}-[a-z]{3}-\d{4} \d{2}:\d{2} (AM|PM)$' THEN   -- 01-May-2025 12:20 PM
        RETURN to_timestamp(v, 'DD-Mon-YYYY HH12:MI AM')::timestamp;
    ELSIF v ~* '^\d{2}-[a-z]{3}-\d{4}$' THEN                      -- 01-May-2025
        RETURN to_timestamp(v, 'DD-Mon-YYYY')::timestamp;
    END IF;
    RETURN NULL;                                                  -- unknown format -> flagged later
END $$;

-- Turns '₹1,234.50', 'Rs. 1234', ' 980.00 ' into NUMERIC; blank -> NULL.
CREATE OR REPLACE FUNCTION staging.parse_amount(v TEXT)
RETURNS NUMERIC(12,2)
LANGUAGE sql IMMUTABLE AS $$
    SELECT NULLIF(
             regexp_replace(
               regexp_replace(trim(v), '^(Rs\.?|₹)\s*', '', 'i'),  -- drop currency prefix
               '[^0-9.]', '', 'g'),                                -- drop commas / spaces
             '')::NUMERIC(12,2)
$$;

-- Normalises any text to a matching key: 'H.S.R Layout ' -> 'hsrlayout'
CREATE OR REPLACE FUNCTION staging.match_key(v TEXT)
RETURNS TEXT
LANGUAGE sql IMMUTABLE AS $$
    SELECT lower(regexp_replace(coalesce(v,''), '[^a-zA-Z]', '', 'g'))
$$;

-- ---------------------------------------------------------------------
-- 2. Lookup table: every known spelling -> one official area name
--    (In a real job this table is maintained by the business, not hard-coded logic.)
-- ---------------------------------------------------------------------
CREATE TABLE staging.area_mapping (
    match_key  TEXT PRIMARY KEY,
    area_name  TEXT NOT NULL,
    zone       TEXT NOT NULL
);

INSERT INTO staging.area_mapping (match_key, area_name, zone) VALUES
 ('koramangala','Koramangala','South-East'), ('kormangala','Koramangala','South-East'),
 ('indiranagar','Indiranagar','East'),       ('hsr','HSR Layout','South-East'),
 ('hsrlayout','HSR Layout','South-East'),    ('whitefield','Whitefield','East'),
 ('jayanagar','Jayanagar','South'),          ('ecity','Electronic City','South'),
 ('electroniccity','Electronic City','South'),('marathahalli','Marathahalli','East'),
 ('marathalli','Marathahalli','East'),       ('btm','BTM Layout','South'),
 ('btmlayout','BTM Layout','South'),         ('malleshwaram','Malleshwaram','North'),
 ('malleswaram','Malleshwaram','North'),     ('hebbal','Hebbal','North');

-- ---------------------------------------------------------------------
-- 3. Clean restaurants
-- ---------------------------------------------------------------------
CREATE TABLE staging.restaurants AS
WITH ranked AS (
    SELECT r.*,
           ROW_NUMBER() OVER (PARTITION BY trim(restaurant_id) ORDER BY loaded_at) AS rn
    FROM raw.restaurants r
)
SELECT
    upper(trim(r.restaurant_id))                                    AS restaurant_id,
    initcap(trim(r.restaurant_name))                                AS restaurant_name,
    coalesce(NULLIF(NULLIF(trim(r.cuisine), ''), 'N/A'), 'Unknown') AS cuisine,
    coalesce(m.area_name, 'Unknown')                                AS area,
    coalesce(m.zone, 'Unknown')                                     AS zone,
    r.avg_cost_for_two::INT                                         AS avg_cost_for_two,
    staging.parse_ts(r.onboarded_on)::DATE                          AS onboarded_on
FROM ranked r
LEFT JOIN staging.area_mapping m ON m.match_key = staging.match_key(r.area)
WHERE r.rn = 1;                                                     -- keep one row per id

ALTER TABLE staging.restaurants ADD PRIMARY KEY (restaurant_id);

-- ---------------------------------------------------------------------
-- 4. Clean orders (typed + standardised, before validation)
-- ---------------------------------------------------------------------
CREATE TABLE staging.orders_typed AS
WITH dedup AS (
    -- the source double-submitted some events: keep the first copy of each order_id
    SELECT o.*,
           ROW_NUMBER() OVER (PARTITION BY trim(order_id) ORDER BY loaded_at) AS rn
    FROM raw.orders o
)
SELECT
    trim(order_id)                                   AS order_id,
    staging.parse_ts(order_time)                     AS order_ts,
    upper(trim(customer_id))                         AS customer_id,
    coalesce(m.area_name, 'Unknown')                 AS customer_area,
    upper(trim(restaurant_id))                       AS restaurant_id,
    NULLIF(trim(items_count), '')::INT               AS items_count,
    staging.parse_amount(order_value)                AS order_value,
    coalesce(staging.parse_amount(discount), 0)      AS discount,
    coalesce(staging.parse_amount(delivery_fee), 0)  AS delivery_fee,
    CASE
        WHEN lower(payment_method) ~ 'upi|gpay|phonepe'   THEN 'UPI'
        WHEN lower(payment_method) ~ 'card'               THEN 'Card'
        WHEN lower(payment_method) ~ 'cod|cash'           THEN 'Cash'
        WHEN lower(payment_method) ~ 'wallet|amazon pay'  THEN 'Wallet'
        ELSE 'Other'
    END                                              AS payment_method,
    CASE
        WHEN lower(trim(order_status)) LIKE 'deliver%'  THEN 'Delivered'
        WHEN lower(trim(order_status)) LIKE 'cancel%'   THEN 'Cancelled'
        WHEN lower(trim(order_status)) LIKE 'refund%'   THEN 'Refunded'
        ELSE 'Unknown'
    END                                              AS order_status,
    NULLIF(trim(delivery_time_min), '')::INT         AS delivery_time_min_raw,
    NULLIF(trim(rating), '')::INT                    AS rating_raw
FROM dedup o
LEFT JOIN staging.area_mapping m ON m.match_key = staging.match_key(o.customer_area)
WHERE o.rn = 1;

-- ---------------------------------------------------------------------
-- 5. Validation: hard errors -> rejected log, soft errors -> nulled + flagged
-- ---------------------------------------------------------------------
CREATE TABLE staging.rejected_orders AS
SELECT t.*,
       CASE
           WHEN t.order_ts IS NULL                         THEN 'Unparseable order time'
           WHEN t.order_value IS NULL                      THEN 'Missing order value'
           WHEN r.restaurant_id IS NULL                    THEN 'Unknown restaurant_id (orphan)'
       END AS reject_reason,
       now() AS rejected_at
FROM staging.orders_typed t
LEFT JOIN staging.restaurants r USING (restaurant_id)
WHERE t.order_ts IS NULL
   OR t.order_value IS NULL
   OR r.restaurant_id IS NULL;

CREATE TABLE staging.orders AS
SELECT
    t.order_id, t.order_ts, t.customer_id, t.customer_area, t.restaurant_id,
    t.items_count, t.order_value, t.discount, t.delivery_fee,
    t.payment_method, t.order_status,
    -- impossible values become NULL (not deleted) so the order still counts in revenue
    CASE WHEN t.delivery_time_min_raw BETWEEN 1 AND 180 THEN t.delivery_time_min_raw END AS delivery_time_min,
    CASE WHEN t.rating_raw BETWEEN 1 AND 5              THEN t.rating_raw            END AS rating,
    (t.delivery_time_min_raw IS NOT NULL AND t.delivery_time_min_raw NOT BETWEEN 1 AND 180) AS dq_bad_delivery_time,
    (t.rating_raw IS NOT NULL AND t.rating_raw NOT BETWEEN 1 AND 5)                         AS dq_bad_rating
FROM staging.orders_typed t
WHERE t.order_id NOT IN (SELECT order_id FROM staging.rejected_orders);

ALTER TABLE staging.orders ADD PRIMARY KEY (order_id);

-- ---------------------------------------------------------------------
-- 6. Cleaning summary (the "after" picture)
-- ---------------------------------------------------------------------
\echo
\echo '==================  CLEANING SUMMARY  =================='
SELECT 'Raw order rows'                    AS step, count(*) AS rows FROM raw.orders
UNION ALL SELECT 'After de-duplication',           count(*) FROM staging.orders_typed
UNION ALL SELECT 'Rejected (logged)',              count(*) FROM staging.rejected_orders
UNION ALL SELECT 'Clean orders in staging',        count(*) FROM staging.orders
UNION ALL SELECT 'Delivery times nulled (bad)',    count(*) FROM staging.orders WHERE dq_bad_delivery_time
UNION ALL SELECT 'Ratings nulled (out of range)',  count(*) FROM staging.orders WHERE dq_bad_rating;

\echo
\echo '---- Rejection reasons ----'
SELECT reject_reason, count(*) AS rows FROM staging.rejected_orders GROUP BY 1 ORDER BY 2 DESC;

\echo
\echo '---- Area labels: raw spellings collapsed into clean names ----'
SELECT (SELECT count(DISTINCT customer_area) FROM raw.orders)     AS raw_spellings,
       (SELECT count(DISTINCT customer_area) FROM staging.orders) AS clean_areas;
