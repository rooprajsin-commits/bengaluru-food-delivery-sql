-- =====================================================================
-- 01_load_raw.sql  (EXTRACT)
-- Loads the CSV files into the raw layer with every column as TEXT.
-- Why TEXT? Source data is messy ("₹1,234.00", "29/10/2025 16:32", "Cancel").
-- Typed columns would make the load fail; we load first, then clean in SQL.
--
-- Run from the project root folder so the relative paths resolve:
--     psql -d food_delivery -f sql/01_load_raw.sql
-- =====================================================================

CREATE TABLE raw.restaurants (
    restaurant_id     TEXT,
    restaurant_name   TEXT,
    cuisine           TEXT,
    area              TEXT,
    avg_cost_for_two  TEXT,
    onboarded_on      TEXT,
    loaded_at         TIMESTAMP DEFAULT now()
);

CREATE TABLE raw.orders (
    order_id           TEXT,
    order_time         TEXT,
    customer_id        TEXT,
    customer_area      TEXT,
    restaurant_id      TEXT,
    items_count        TEXT,
    order_value        TEXT,
    discount           TEXT,
    delivery_fee       TEXT,
    payment_method     TEXT,
    order_status       TEXT,
    delivery_time_min  TEXT,
    rating             TEXT,
    loaded_at          TIMESTAMP DEFAULT now()
);

-- \copy runs on the client, so it works on a laptop install without superuser rights
\copy raw.restaurants (restaurant_id, restaurant_name, cuisine, area, avg_cost_for_two, onboarded_on) FROM 'data/restaurants_raw.csv' WITH (FORMAT csv, HEADER true, ENCODING 'UTF8')
\copy raw.orders (order_id, order_time, customer_id, customer_area, restaurant_id, items_count, order_value, discount, delivery_fee, payment_method, order_status, delivery_time_min, rating) FROM 'data/orders_raw.csv' WITH (FORMAT csv, HEADER true, ENCODING 'UTF8')

SELECT 'raw.restaurants' AS table_name, count(*) AS rows_loaded FROM raw.restaurants
UNION ALL
SELECT 'raw.orders', count(*) FROM raw.orders;
